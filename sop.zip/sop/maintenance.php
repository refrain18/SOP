<title>Site Maintenance</title>
<style>
  h1 { font-size: 50px; }
  article { display: block; text-align: left; width: 650px; margin: 0 auto; margin-top:160px;}
</style>

<article> 
    <h1>We&rsquo;ll be back soon!</h1>
    <div>
        <p>Maaf Website Sedang Maintenance</p>
        <p>&mdash; Si Tampan Abka</p>
    </div>
</article>