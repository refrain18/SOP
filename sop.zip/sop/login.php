<!DOCTYPE HTML>
<html>
   <head>
      <title>Login SOP</title>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <link rel="stylesheet" href="css/style.css">
   </head>
   <body>
      <div class="container">
         <section class="login-box">
            <h2>Login Sistem Standard Operating Procedure Salon Mumtaza</h2>
            <form method="post" action="ceklogin.php">
               <input type="text" placeholder="Username" name="username">
               <input type="password" placeholder="Password" name="password">
               <input type="submit" value="Login">
            </form>
         </div>
      </div>
   </body>
</html>