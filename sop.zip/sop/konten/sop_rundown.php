<?php
   if(!defined('INDEX')) die("");
?>
